dim speechobject
set speechobject=createobject("sapi.spvoice")

x = msgbox("Ce logiciel permet de dissuader d'utiliser ou de bloquer les fichiers qui vos distraient (ex: jeux videos) et de passer a ce que vous devez faire. Appuyez sur OK pour commencer. Ce logiciel a etait creer par Gold Infinity", 10, "Installer")

x = msgbox("Pour installer Anti-distractions Infinity, appuyez sur OUI.", 4, "Installer")

If x <> 6 Then
    WScript.Quit
End If

speechobject.speak "Installation de Anti-distractions Infinity en cours... veulliez patienter un peu pour le telechargement des donner..."
WScript.Sleep 10000

Set fso = CreateObject("Scripting.FileSystemObject")

nomDossier = "files program"

cheminSource = fso.GetParentFolderName(WScript.ScriptFullName) & "\" & nomDossier

cheminDestination = "C:\" & nomDossier

If fso.FolderExists(cheminSource) Then
    On Error Resume Next
    fso.CopyFolder cheminSource, cheminDestination, True
    
    If Err.Number = 0 Then
        
    Else
        MsgBox "Erreur lors de la copie : " & Err.Description, 16, "Erreur"
    End If
    On Error GoTo 0
Else
    MsgBox "Erreur : Le dossier source '" & nomDossier & "' est introuvable.", 48, "Dossier manquant"
End If

CreateObject("WScript.Shell").Run "wscript ""C:\files program\Ins.vbs"""

WScript.Quit