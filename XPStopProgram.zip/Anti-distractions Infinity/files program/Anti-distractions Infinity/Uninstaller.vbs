dim speechobject
set speechobject=createobject("sapi.spvoice")

x = msgbox("Pour desinstaller Anti-distractions Infinity, appuyez sur OUI. Cette action est irrevercible", 4, "Uninstaller")

If x <> 6 Then
    WScript.Quit
End If

speechobject.speak "Desinstallation de Anti-distractions Infinity en cours... veulliez patienter un peu pour la suppression des donner..."

WScript.Sleep 10000

strFileName = "C:\files program\dis.vbs"
Set objWMIService = GetObject("winmgmts:\\.\root\cimv2")
Set colItems = objWMIService.ExecQuery("Select * from Win32_Process Where Name = 'wscript.exe' OR Name = 'cscript.exe'")

For Each objItem In colItems
    If InStr(objItem.CommandLine, strFileName) > 0 Then
        objItem.Terminate()
    End If
Next

strFileName = "C:\files program\Timer-launch.vbs"
Set objWMIService = GetObject("winmgmts:\\.\root\cimv2")
Set colItems = objWMIService.ExecQuery("Select * from Win32_Process Where Name = 'wscript.exe' OR Name = 'cscript.exe'")

For Each objItem In colItems
    If InStr(objItem.CommandLine, strFileName) > 0 Then
        objItem.Terminate()
    End If
Next

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

startupPath = shell.SpecialFolders("Startup")

fileName = "dec.vbs"
fullPath = startupPath & "\" & fileName

If fso.FileExists(fullPath) Then
    fso.DeleteFile fullPath, True
End If

Set fso = Nothing
Set shell = Nothing


Set fso = CreateObject("Scripting.FileSystemObject")

cheminDossier = "C:\files program"

If fso.FolderExists(cheminDossier) Then
    On Error Resume Next
    fso.DeleteFolder cheminDossier, True
    
    If Err.Number = 0 Then
        
    Else
        
    End If
    On Error GoTo 0
Else
    MsgBox "Le dossier est introuvable.", 48, "Information"
End If

Set fso = Nothing

Set shell = CreateObject("WScript.Shell")
shell.Popup "La desinstallation de Anti-distractions Infinity a ete terminer, vous pouvez supprimer ce dossier.", 5, "Uninstaller", 64