Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

cheminBureau = shell.SpecialFolders("Startup")

dossierActuel = fso.GetParentFolderName(WScript.ScriptFullName)

nomFichierSource = "dec.vbs"
nomFichierCopie = "dec.vbs"

cheminSource = fso.BuildPath(dossierActuel, nomFichierSource)
cheminDestination = fso.BuildPath(cheminBureau, nomFichierCopie)

If fso.FileExists(cheminSource) Then
    fso.CopyFile cheminSource, cheminDestination, True
Else
    MsgBox "Erreur : Le fichier '" & nomFichierSource & "' est introuvable dans : " & dossierActuel, 16, "Échec"
End If

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

nomDossierSource = "Anti-distractions Infinity"
nomFichierCible = "munu principal.vbs"
nomRaccourci = "Anti-distractions Infinity.lnk"

cheminActuel = fso.GetParentFolderName(WScript.ScriptFullName)
cheminSource = fso.BuildPath(cheminActuel, nomDossierSource)

cheminBureau = shell.SpecialFolders("Desktop")
cheminDestination = fso.BuildPath(cheminBureau, nomDossierSource)

If fso.FolderExists(cheminSource) Then
    On Error Resume Next
    fso.CopyFolder cheminSource, cheminDestination, True
    
    If Err.Number = 0 Then
        
        cheminCibleVBS = fso.BuildPath(cheminActuel, nomFichierCible)
        cheminLien = fso.BuildPath(cheminDestination, nomRaccourci)
        
        Set raccourci = shell.CreateShortcut(cheminLien)
        raccourci.TargetPath = cheminCibleVBS
        raccourci.WorkingDirectory = cheminDestination
        raccourci.Description = "Ouvrir le menu principal"
        raccourci.IconLocation = "shell32.dll, 239" 
        raccourci.Save
        
        
    Else
        MsgBox "Erreur durant la copie : " & Err.Description, 16, "Erreur"
    End If
    On Error GoTo 0
Else
    MsgBox "Le dossier source '" & nomDossierSource & "' est introuvable.", 48, "Erreur"
End If

Set fso = Nothing
Set shell = Nothing

WScript.Sleep 5000

Set shell = CreateObject("WScript.Shell")
shell.Popup "L'installation de Anti-distractions Infinity a ete terminer.", 5, "Installer", 64

WScript.Quit