Do While 1<2

x = msgbox("Veuliez attendre un moment...", 10, "Chargement...")

loop
