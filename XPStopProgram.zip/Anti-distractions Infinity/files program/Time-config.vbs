Dim fso, file, debutInput, finInput, totalInput, currentDir
Set fso = CreateObject("Scripting.FileSystemObject")

currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

debutInput = InputBox("Entrez l'heure de demarrage (Format HH:MM) :" & vbCrLf & "Exemple: 15:00", "Configuration nouvelle plage horraire - Demarrage")
If debutInput = "" Then WScript.Quit

finInput = InputBox("Entrez l'heure d'arret (Format HH:MM) :" & vbCrLf & "Exemple: 16:30", "Configuration nouvelle plage horraire - Arret")
If finInput = "" Then WScript.Quit

If Len(debutInput) = 5 And Len(finInput) = 5 Then
    totalInput = debutInput & "-" & finInput
    
    Set file = fso.OpenTextFile(currentDir & "\time.txt", 8, True)
    file.WriteLine(totalInput)
    file.Close
    MsgBox "Plage horaire enregistrer.", 64, "Configuration nouvelle plage horraire"
Else
    MsgBox "Format incorrect, veuillez respecter le format HH:MM (ex: 15:00).", 16, "Erreur"
End If