Dim fso, file, currentDir, activeTimer, line, executionActive, fullFileContent, lineToReplace
Set fso = CreateObject("Scripting.FileSystemObject")

currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

Do
    executionActive = "0"
    If fso.FileExists(currentDir & "\settings.txt") Then
        Set file = fso.OpenTextFile(currentDir & "\settings.txt", 1)
        If Not file.AtEndOfStream Then file.ReadLine ' Ligne 1
        If Not file.AtEndOfStream Then file.ReadLine ' Ligne 2
        If Not file.AtEndOfStream Then executionActive = Trim(file.ReadLine) ' Ligne 3
        file.Close
    End If

    If executionActive <> "1" Then
        WScript.Sleep 2000 
    Else
        activeTimer = ""
        lineToReplace = ""
        fullFileContent = ""
        
        If fso.FileExists(currentDir & "\time.txt") Then
            Set file = fso.OpenTextFile(currentDir & "\time.txt", 1)
            Do Until file.AtEndOfStream
                line = file.ReadLine
                If Left(line, 1) = "*" Then
                    lineToReplace = line
                    activeTimer = Replace(line, "*", "") ' On nettoie les * pour le calcul
                End If
                fullFileContent = fullFileContent & line & vbCrLf
            Loop
            file.Close
        End If

        If activeTimer <> "" Then
            Dim parts, heureDebut, heureFin, heureActuelle, statusNouveau
            parts = Split(activeTimer, "-")
            heureDebut = parts(0)
            heureFin = parts(1)
            
            heureActuelle = Right("0" & Hour(Time), 2) & ":" & Right("0" & Minute(Time), 2)
            
            If heureDebut <= heureFin Then
                If heureActuelle >= heureDebut And heureActuelle < heureFin Then statusNouveau = "1" Else statusNouveau = "0"
            Else
                If heureActuelle >= heureDebut Or heureActuelle < heureFin Then statusNouveau = "1" Else statusNouveau = "0"
            End If
            
            Dim l1, l2, l3, reste
            l1 = "0" : l2 = "" : l3 = "" : reste = ""
            If fso.FileExists(currentDir & "\settings.txt") Then
                Set file = fso.OpenTextFile(currentDir & "\settings.txt", 1)
                If Not file.AtEndOfStream Then l1 = Trim(file.ReadLine)
                If Not file.AtEndOfStream Then l2 = file.ReadLine
                If Not file.AtEndOfStream Then l3 = file.ReadLine
                If Not file.AtEndOfStream Then reste = file.ReadAll
                file.Close
            End If
            
            If statusNouveau = "1" And l1 <> "1" And Left(lineToReplace, 2) <> "**" Then
                Set file = fso.OpenTextFile(currentDir & "\settings.txt", 2, True)
                file.Write "1" & vbCrLf & l2 & vbCrLf & l3
                If reste <> "" Then file.Write vbCrLf & reste
                file.Close
                
                fullFileContent = Replace(fullFileContent, lineToReplace & vbCrLf, "*" & lineToReplace & vbCrLf)
                Set file = fso.OpenTextFile(currentDir & "\time.txt", 2, True)
                file.Write fullFileContent
                file.Close
            
            ElseIf statusNouveau = "0" And l1 = "1" And Left(lineToReplace, 2) = "**" Then
                Set file = fso.OpenTextFile(currentDir & "\settings.txt", 2, True)
                file.Write "0" & vbCrLf & l2 & vbCrLf & l3
                If reste <> "" Then file.Write vbCrLf & reste
                file.Close
                
                Dim restoredLine
                restoredLine = Mid(lineToReplace, 2) ' Enlève un astérisque
                fullFileContent = Replace(fullFileContent, lineToReplace & vbCrLf, restoredLine & vbCrLf)
                Set file = fso.OpenTextFile(currentDir & "\time.txt", 2, True)
                file.Write fullFileContent
                file.Close
                
            ElseIf statusNouveau = "0" And l1 = "0" And Left(lineToReplace, 2) = "**" Then
                Dim cleanedLine
                cleanedLine = Mid(lineToReplace, 2)
                fullFileContent = Replace(fullFileContent, lineToReplace & vbCrLf, cleanedLine & vbCrLf)
                Set file = fso.OpenTextFile(currentDir & "\time.txt", 2, True)
                file.Write fullFileContent
                file.Close
            End If
        End If
        
        WScript.Sleep 1000
    End If
Loop