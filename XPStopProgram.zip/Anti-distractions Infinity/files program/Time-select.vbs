Dim fso, file, line, count, choix, i, cleanLine, listContent, allLines, currentDir
Set fso = CreateObject("Scripting.FileSystemObject")

currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

If Not fso.FileExists(currentDir & "\time.txt") Then
    MsgBox "Le fichier time.txt n'existe pas.", 16, "Erreur"
    WScript.Quit
End If

Set file = fso.OpenTextFile(currentDir & "\time.txt", 1)
listContent = ""
count = 0
Set allLines = CreateObject("Scripting.Dictionary")

Do Until file.AtEndOfStream
    line = file.ReadLine
    If Trim(line) <> "" Then
        count = count + 1
        cleanLine = Replace(line, "*", "")
        listContent = listContent & count & " - de " & Replace(cleanLine, "-", " a ") & vbCrLf
        allLines.Add count, cleanLine
    End If
Loop
file.Close

If count = 0 Then
    MsgBox "Aucune plage horaire enregistree.", 48, "Information"
    WScript.Quit
End If

choix = InputBox("Choisissez le numero de la plage horaire a activer :" & vbCrLf & vbCrLf & listContent, "Selectioner une plage horraire")
If choix = "" Then WScript.Quit

If Not IsNumeric(choix) Then
    MsgBox "Veuillez entrer un chiffre valide.", 16, "Erreur"
    WScript.Quit
ElseIf CInt(choix) < 1 Or CInt(choix) > count Then
    MsgBox "Numero invalide.", 16, "Erreur"
    WScript.Quit
End If

Set file = fso.OpenTextFile(currentDir & "\time.txt", 2, True)
For i = 1 To count
    If i = CInt(choix) Then
        file.WriteLine("*" & allLines(i))
    Else
        file.WriteLine(allLines(i))
    End If
Next
file.Close

MsgBox "Plage horaire selectionner.", 64, "Selectioner une plage horraire"