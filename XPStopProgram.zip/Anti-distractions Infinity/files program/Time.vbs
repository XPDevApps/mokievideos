Dim shell, fso, file, choix, activeTimer, line, currentDir, modeHoraire
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

Do
    activeTimer = "Aucune (Veuillez en selectionner une)"
    If fso.FileExists(currentDir & "\time.txt") Then
        Set file = fso.OpenTextFile(currentDir & "\time.txt", 1)
        Do Until file.AtEndOfStream
            line = file.ReadLine
            If Left(line, 1) = "*" Then
                activeTimer = Replace(line, "*", "")
                Exit Do
            End If
        Loop
        file.Close
    End If

    modeHoraire = "DESACTIVE"
    If fso.FileExists(currentDir & "\settings.txt") Then
        Set file = fso.OpenTextFile(currentDir & "\settings.txt", 1)
        If Not file.AtEndOfStream Then file.ReadLine ' Saute ligne 1
        If Not file.AtEndOfStream Then file.ReadLine ' Saute ligne 2
        If Not file.AtEndOfStream Then 
            If file.ReadLine = "1" Then modeHoraire = "ACTIVE"
        End If
        file.Close
    End If

    ' 3. Affichage du Menu
    choix = InputBox("CONFIGURATION DES PLAGES HORAIRES" & vbCrLf & _
                     "Plage actuelle: de " & Replace(activeTimer, "-", " a ") & vbCrLf & _
                     "Statut: " & modeHoraire & vbCrLf & vbCrLf & _
                     "1 - Activer / Desactiver l'activation horraire" & vbCrLf & _
                     "2 - Selectionner une plage horraire" & vbCrLf & _
                     "3 - Configurer une nouvelle plage horraire" & vbCrLf & _
                     "4 - Supprimer une plage horraire", "Plages horraires")
                     
    If choix = "" Then Exit Do

    Select Case choix
        Case "1"
            Dim nV, l1, l2, reste
            l1 = "0" : l2 = "" : reste = ""
            If modeHoraire = "ACTIVE" Then nV = "0" Else nV = "1"
            
            If fso.FileExists(currentDir & "\settings.txt") Then
                Set file = fso.OpenTextFile(currentDir & "\settings.txt", 1)
                If Not file.AtEndOfStream Then l1 = file.ReadLine
                If Not file.AtEndOfStream Then l2 = file.ReadLine
                If Not file.AtEndOfStream Then file.ReadLine ' Ignore l'ancienne ligne 3
                If Not file.AtEndOfStream Then reste = file.ReadAll
                file.Close
            End If
            
            Set file = fso.OpenTextFile(currentDir & "\settings.txt", 2, True)
            file.Write l1 & vbCrLf & l2 & vbCrLf & nV
            If reste <> "" Then file.Write vbCrLf & reste
            file.Close
            
            If nV = "1" Then
                MsgBox "Surveillance horaire activee !", 64, "Statut"
            Else
                MsgBox "Surveillance horaire desactivee !", 48, "Statut"
            End If

        Case "2"
            shell.Run "wscript " & Chr(34) & currentDir & "\Time-select.vbs" & Chr(34), 1, True
        Case "3"
            shell.Run "wscript " & Chr(34) & currentDir & "\Time-config.vbs" & Chr(34), 1, True
        Case "4"
            shell.Run "wscript " & Chr(34) & currentDir & "\Time-delete.vbs" & Chr(34), 1, True
        Case Else
            MsgBox "Option invalide.", 48, "Attention"
    End Select
Loop