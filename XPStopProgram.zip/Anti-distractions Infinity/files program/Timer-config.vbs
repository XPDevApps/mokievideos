Dim fso, file, timerInput, currentDir
Set fso = CreateObject("Scripting.FileSystemObject")

' Recuperation automatique et corrigee du dossier actuel
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

' Demande le timer a l'utilisateur
timerInput = InputBox("Entrez la duree du timer (Format HH:MM:SS) :" & vbCrLf & "Exemple: 00:25:00 pour 25 minutes", "Configuration du Timer")

' Verification basique du format (8 caracteres)
If Len(timerInput) = 8 Then
    ' Ouverture de Timer.txt securisee avec currentDir
    Set file = fso.OpenTextFile(currentDir & "\Timer.txt", 8, True)
    file.WriteLine(timerInput)
    file.Close
    MsgBox "Timer enregistrer.", 64, "Configuration du Timer"
ElseIf timerInput <> "" Then
    MsgBox "Format incorrect. Veuillez respecter le format HH:MM:SS", 16, "Configuration du Timer - Erreur"
End If