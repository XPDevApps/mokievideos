Dim fso, file, lines, line, count, choix, i, cleanLine, currentDir
Set fso = CreateObject("Scripting.FileSystemObject")

' Recuperation automatique et corrigee du dossier actuel
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

' Lecture de Timer.txt pour affichage
If Not fso.FileExists(currentDir & "\Timer.txt") Then
    MsgBox "Le fichier Timer.txt n'existe pas.", 16, "Erreur"
    WScript.Quit
End If

Set file = fso.OpenTextFile(currentDir & "\Timer.txt", 1)
Dim listContent, allLines
listContent = ""
count = 0
Set allLines = CreateObject("Scripting.Dictionary")

Do Until file.AtEndOfStream
    line = file.ReadLine
    If Trim(line) <> "" Then
        count = count + 1
        cleanLine = Replace(line, "*", "")
        listContent = listContent & count & " - " & cleanLine & vbCrLf
        allLines.Add count, cleanLine
    End If
Loop
file.Close

If count = 0 Then
    MsgBox "Aucun timer enregistre.", 48, "Information"
    WScript.Quit
End If

' Choix de l'utilisateur
choix = InputBox("Choisissez le numero du timer a selectionner :" & vbCrLf & vbCrLf & listContent, "Selection du Timer")

If choix = "" Then WScript.Quit

If Not IsNumeric(choix) Then
    MsgBox "Veuillez entrer un chiffre valide.", 16, "Erreur"
    WScript.Quit
ElseIf CInt(choix) < 1 Or CInt(choix) > count Then
    MsgBox "Numero de timer invalide.", 16, "Erreur"
    WScript.Quit
End If

' Reecriture de Timer.txt avec currentDir
Set file = fso.OpenTextFile(currentDir & "\Timer.txt", 2, True)
For i = 1 To count
    If i = CInt(choix) Then
        file.WriteLine("*" & allLines(i))
    Else
        file.WriteLine(allLines(i))
    End If
Next
file.Close

MsgBox "Timer selectionne avec succes ! Pret a etre lance.", 64, "Succes"