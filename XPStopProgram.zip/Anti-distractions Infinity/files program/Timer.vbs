Dim shell, fso, file, choix, activeTimer, line, currentDir
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Recuperation automatique du dossier actuel
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

Do
    ' Recherche du timer selectionne (qui commence par *) dans Timer.txt
    activeTimer = "Aucun (Veuillez en selectionner un)"
    If fso.FileExists(currentDir & "\Timer.txt") Then
        Set file = fso.OpenTextFile(currentDir & "\Timer.txt", 1)
        Do Until file.AtEndOfStream
            line = file.ReadLine
            If Left(line, 1) = "*" Then
                activeTimer = Replace(line, "*", "") ' On enleve le * pour l'interface
                Exit Do
            End If
        Loop
        file.Close
    End If

    choix = InputBox("--- TIMER ---" & vbCrLf & _
                     "Timer selectionne actuel : " & activeTimer & vbCrLf & vbCrLf & _
                     "1 - Lancer le timer." & vbCrLf & _
                     "2 - Changer le timer" & vbCrLf & _
                     "3 - Configurer un nouveau timer" & vbCrLf & _
                     "4 - Supprimer un timer", "Anti-Distraction Infinity - Timer")
                     
    If choix = "" Then Exit Do

    Select Case choix
        Case "1"
            If activeTimer = "Aucun (Veuillez en selectionner un)" Then
                MsgBox "Veuillez d'abord selectionner un timer via l'option 2.", 48, "Attention"
            Else
                LancerCompteARebours activeTimer
            End If
        Case "2"
            shell.Run "wscript " & Chr(34) & currentDir & "\Timer-select.vbs" & Chr(34), 1, True
        Case "3"
            shell.Run "wscript " & Chr(34) & currentDir & "\Timer-config.vbs" & Chr(34), 1, True
        Case "4"
            shell.Run "wscript " & Chr(34) & currentDir & "\Timer-delete.vbs" & Chr(34), 1, True
        Case Else
            MsgBox "Option invalide. Veuillez choisir entre 1 et 4.", 48, "Attention"
    End Select
Loop

Sub LancerCompteARebours(durationStr)
    Dim remainingContent, timeParts, totalSeconds, i, l2, l3, reste, tempLine
    
    timeParts = Split(durationStr, ":")
    totalSeconds = (CInt(timeParts(0)) * 3600) + (CInt(timeParts(1)) * 60) + CInt(timeParts(2))

    l2 = "0" : l3 = "0" : reste = ""
    If fso.FileExists(currentDir & "\settings.txt") Then
        Set file = fso.OpenTextFile(currentDir & "\settings.txt", 1)
        If Not file.AtEndOfStream Then file.ReadLine ' Saute la ligne 1 actuelle
        
        If Not file.AtEndOfStream Then 
            tempLine = file.ReadLine
            If Trim(tempLine) <> "" Then l2 = tempLine ' Sauvegarde de ton mode de blocage !
        End If
        
        If Not file.AtEndOfStream Then 
            tempLine = file.ReadLine
            If Trim(tempLine) <> "" Then l3 = tempLine ' Sauvegarde de la plage horaire
        End If
        
        If Not file.AtEndOfStream Then reste = file.ReadAll
        file.Close
    End If

    ' Activation du blocage (Ligne 1 = 1)
    Set file = fso.OpenTextFile(currentDir & "\settings.txt", 2, True)
    file.Write "1" & vbCrLf & l2 & vbCrLf & l3
    If reste <> "" Then file.Write vbCrLf & reste
    file.Close

    MsgBox "Timer de " & durationStr & " est lance", 64, "Anti-Distractions Infinity - Timer"

    For i = 1 To totalSeconds
        WScript.Sleep 1000
    Next

    l2 = "0" : l3 = "0" : reste = ""
    If fso.FileExists(currentDir & "\settings.txt") Then
        Set file = fso.OpenTextFile(currentDir & "\settings.txt", 1)
        If Not file.AtEndOfStream Then file.ReadLine
        
        If Not file.AtEndOfStream Then 
            tempLine = file.ReadLine
            If Trim(tempLine) <> "" Then l2 = tempLine ' On reprend ton precieux mode de blocage
        End If
        
        If Not file.AtEndOfStream Then 
            tempLine = file.ReadLine
            If Trim(tempLine) <> "" Then l3 = tempLine
        End If
        
        If Not file.AtEndOfStream Then reste = file.ReadAll
        file.Close
    End If

    Set file = fso.OpenTextFile(currentDir & "\settings.txt", 2, True)
    file.Write "0" & vbCrLf & l2 & vbCrLf & l3
    If reste <> "" Then file.Write vbCrLf & reste
    file.Close

    MsgBox "Le temps est ecoule ! Anti-distractions desactive.", 64, "Anti-distractions Infinity - Timer"
End Sub