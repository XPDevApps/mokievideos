CreateObject("WScript.Shell").Run "wscript ""C:\files program\dis.vbs"""

CreateObject("WScript.Shell").Run "wscript ""C:\files program\Time-launch.vbs"""