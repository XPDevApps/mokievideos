Option Explicit

Dim fso, shell, objWMIService, currentDir, settingsFile, logFile
Dim activation, modeAction, fileStream, colProcesses, filePath, fileName, objProcess
Dim exceptionJeu, reponse, delai, colItems, objItem, dictProcesses
Dim realName

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
settingsFile = currentDir & "\settings.txt"
logFile = currentDir & "\fichiers_selec.txt"

exceptionJeu = ""

Function GetWMI()
    On Error Resume Next
    Set GetWMI = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2")
    On Error GoTo 0
End Function

Set objWMIService = GetWMI()

Do
    If objWMIService Is Nothing Then Set objWMIService = GetWMI()

    activation = "1"
    modeAction = "0"
    If fso.FileExists(settingsFile) Then
        On Error Resume Next
        Set fileStream = fso.OpenTextFile(settingsFile, 1)
        activation = Trim(fileStream.ReadLine)
        modeAction = Trim(fileStream.ReadLine)
        fileStream.Close
        On Error GoTo 0
    End If

    ' Vérification de l'exception de jeu (autorisation accordée)
    If exceptionJeu <> "" Then
        On Error Resume Next
        Dim checkProc
        Set checkProc = objWMIService.ExecQuery("Select Name from Win32_Process Where Name = '" & exceptionJeu & "'")
        If Err.Number <> 0 Or checkProc.Count = 0 Then exceptionJeu = ""
        On Error GoTo 0
    End If

    If activation = "1" Then
        If fso.FileExists(logFile) Then
            
            ' Création de l'inventaire des processus actifs
            Set dictProcesses = CreateObject("Scripting.Dictionary")
            On Error Resume Next
            Set colProcesses = objWMIService.ExecQuery("Select Name from Win32_Process")
            
            If Err.Number = 0 Then
                For Each objProcess In colProcesses
                    dictProcesses(LCase(objProcess.Name)) = objProcess.Name
                Next
            End If
            On Error GoTo 0
            
            Set fileStream = fso.OpenTextFile(logFile, 1)
            
            Do Until fileStream.AtEndOfStream
                filePath = Trim(fileStream.ReadLine)
                
                ' Nettoyage propre du chemin d'accès
                If InStr(filePath, ":") > 0 Then
                    filePath = Mid(filePath, InStr(filePath, ":") - 1)
                End If
                filePath = Replace(filePath, Chr(34), "") 

                If filePath <> "" Then
                    fileName = fso.GetFileName(filePath)
                    
                    If fileName <> "" And LCase(fileName) <> LCase(exceptionJeu) Then
                        
                        ' Si l'application est détectée dans les processus actifs
                        If dictProcesses.Exists(LCase(fileName)) Then
                            realName = dictProcesses(LCase(fileName))
                            
                            ' --- DESTRUCTION DU PROCESSUS ---
                            shell.Run "taskkill /F /IM " & Chr(34) & realName & Chr(34), 0, True
                            
                            ' Pause de sécurité pour laisser Windows nettoyer la mémoire
                            WScript.Sleep 100
                            
                            ' On retire immédiatement le jeu du dictionnaire pour éviter le spam
                            If dictProcesses.Exists(LCase(fileName)) Then
                                dictProcesses.Remove(LCase(fileName))
                            End If
                            
                            ' --- TRAITEMENT SELON LE MODE ---
                            If modeAction = "1" Then
                                ' --- MODE 1 : BLOCAGE STRICT (SANS PAUSE) ---
                                If fso.FileExists(currentDir & "\pop-up.vbs") Then
                                    shell.Run "wscript.exe " & Chr(34) & currentDir & "\pop-up.vbs" & Chr(34), 1, False
                                End If
                            Else
                                ' --- MODE 0 : FAUX CHARGEMENT ---
                                If fso.FileExists(currentDir & "\load_pop.vbs") Then
                                    shell.Run "wscript.exe " & Chr(34) & currentDir & "\load_pop.vbs" & Chr(34), 1, False
                                End If
                                    
                                Randomize
                                delai = Int((40 - 20 + 1) * Rnd + 20)
                                WScript.Sleep (delai * 1000)
                                    
                                On Error Resume Next
                                Set colItems = objWMIService.ExecQuery("Select * from Win32_Process Where Name = 'wscript.exe'")
                                For Each objItem In colItems
                                    If InStr(1, objItem.CommandLine, "load_pop.vbs", 1) > 0 Then objItem.Terminate()
                                Next
                                On Error GoTo 0
                                    
                                reponse = MsgBox("Voulez-vous encore ouvrir ce fichier ?", 4 + 32, "Anti-distraction Infinity")
                                    
                                If reponse = vbYes Then
                                    If fso.FileExists(filePath) Then
                                        exceptionJeu = realName
                                        shell.CurrentDirectory = fso.GetParentFolderName(filePath)
                                        shell.Run Chr(34) & filePath & Chr(34), 1, False
                                    End If
                                End If
                            End If
                            
                        End If
                    End If
                End If
            Loop
            fileStream.Close
        End If
    End If
    WScript.Sleep 1000
Loop