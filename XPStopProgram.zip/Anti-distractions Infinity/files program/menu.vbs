Option Explicit

Dim fso, shell, logFile, selectedFile, fileStream, command, tempFile, currentDir
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
logFile = currentDir & "\fichiers_selec.txt"
tempFile = currentDir & "\temp_path.txt" ' Fichier temporaire pour récupérer le chemin

command = "powershell -WindowStyle Hidden -Command ""Add-Type -AssemblyName System.Windows.Forms; " & _
          "$f = New-Object System.Windows.Forms.OpenFileDialog; " & _
          "$f.InitialDirectory = 'C:\'; " & _
          "if($f.ShowDialog() -eq 'OK') { $f.FileName | Out-File -FilePath '" & tempFile & "' -Encoding UTF8 }"""

shell.Run command, 0, True

If fso.FileExists(tempFile) Then
    Set fileStream = fso.OpenTextFile(tempFile, 1)
    selectedFile = Trim(fileStream.ReadAll)
    fileStream.Close
    fso.DeleteFile(tempFile) ' On supprime le fichier temporaire
End If

If Len(selectedFile) > 0 Then
    On Error Resume Next
    Set fileStream = fso.OpenTextFile(logFile, 8, True, 0)
    
    If Err.Number = 0 Then
        fileStream.WriteLine selectedFile
        fileStream.Close
        MsgBox "Fichier ajouter dans la liste des fichiers distrayants", 64, "Succes"
    Else
        MsgBox "Erreur d'écriture : " & Err.Description, 16, "Erreur"
    End If
    On Error GoTo 0
Else
    MsgBox "Le menu a ete fermer ou aucun fichier n'a ete choisi.", 48, "Infos"
End If