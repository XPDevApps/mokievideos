Option Explicit

Dim fso, shell, logFile, currentDir, choix, command, exec, selectedFile

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
logFile = currentDir & "\fichiers_selec.txt"

choix = InputBox("Gestion de la liste anti-distraction:" & vbCrLf & vbCrLf & _
                 "1: Ajouter un fichier a bloquer." & vbCrLf & _
                 "2: Supprimer ou voir les fichiers de la liste des fichers distrayants." & vbCrLf & _
                 "3: Parametres" & vbCrLf & _
                 "4: Timer", "Anti-distractions Infinity", "1")

Select Case choix
    Case "1"
        AjouterFichier
    Case "2"
        SupprimerFichier
    Case "3"
        shell.Run "wscript " & Chr(34) & currentDir & "\settings.vbs" & Chr(34)
    Case "4"
        shell.Run "wscript " & Chr(34) & currentDir & "\Timer.vbs" & Chr(34)
    Case Else
End Select

Sub AjouterFichier()
    command = "powershell -WindowStyle Hidden -Command ""Add-Type -AssemblyName System.Windows.Forms; " & _
              "$f = New-Object System.Windows.Forms.OpenFileDialog; " & _
              "if($f.ShowDialog() -eq 'OK') { Write-Host $f.FileName }"""
    Set exec = shell.Exec(command)
    
    ' Nettoyage complet de tous les types de retours à la ligne (PowerShell envoie souvent vbCrLf ou vbLf)
    selectedFile = exec.StdOut.ReadAll
    selectedFile = Replace(selectedFile, vbCrLf, "")
    selectedFile = Replace(selectedFile, vbCr, "")
    selectedFile = Replace(selectedFile, vbLf, "")
    selectedFile = Trim(selectedFile)
    
    If selectedFile <> "" Then
        Dim ts
        Set ts = fso.OpenTextFile(logFile, 8, True, 0)
        ts.WriteLine selectedFile
        ts.Close
        MsgBox "Fichier ajoute a la liste des fichers distrayants.", 64, "Ajouter un fichier a bloquer"
    End If
End Sub

Sub SupprimerFichier()
    If Not fso.FileExists(logFile) Then 
        MsgBox "La liste est vide.", 48, "Erreur"
        Exit Sub
    End If
    
    ' Le filtre interne élimine les lignes vides pour l'affichage GridView
    command = "powershell -WindowStyle Hidden -Command ""$l = Get-Content '" & logFile & "' -Encoding UTF8 | Where-Object { $_.Trim() -ne '' }; " & _
              "$s = $l | Out-GridView -Title 'Choisissez le fichier a DEBLOQUER' -OutputMode Single; " & _
              "if($s) { Write-Host $s }"""
    Set exec = shell.Exec(command)
    
    selectedFile = exec.StdOut.ReadAll
    selectedFile = Replace(selectedFile, vbCrLf, "")
    selectedFile = Replace(selectedFile, vbCr, "")
    selectedFile = Replace(selectedFile, vbLf, "")
    selectedFile = Trim(selectedFile)
    
    If selectedFile <> "" Then
        Dim lignes, ligne, nouvelleListe
        Set lignes = fso.OpenTextFile(logFile, 1)
        nouvelleListe = ""
        
        Do Until lignes.AtEndOfStream
            ligne = Trim(lignes.ReadLine)
            ' SÉCURITÉ : On ne garde la ligne que si elle n'est PAS vide ET qu'elle ne correspond pas au fichier sélectionné
            If ligne <> "" And ligne <> selectedFile Then
                nouvelleListe = nouvelleListe & ligne & vbCrLf
            End If
        Loop
        lignes.Close
        
        Set lignes = fso.CreateTextFile(logFile, True)
        lignes.Write nouvelleListe
        lignes.Close
        MsgBox "Fichier retirer de la liste des fichers distrayants.", 64, "Suppression d'un fichier distrayants"
    End If
End Sub