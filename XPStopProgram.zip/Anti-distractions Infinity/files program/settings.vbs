Option Explicit
Dim fso, shell, currentDir, settingsFile, choix, flux, etatActuel, modeActuel, plageActuelle, statut, modeTxt

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
settingsFile = currentDir & "\settings.txt"

' Initialisation des valeurs par defaut au cas ou le fichier est vide
etatActuel = "0"
modeActuel = "0"
plageActuelle = "0"

' 1. Lecture complete et nettoyage (Trim) des 3 lignes existantes
If fso.FileExists(settingsFile) Then
    Set flux = fso.OpenTextFile(settingsFile, 1)
    If Not flux.AtEndOfStream Then etatActuel = Trim(flux.ReadLine)
    If Not flux.AtEndOfStream Then modeActuel = Trim(flux.ReadLine)
    If Not flux.AtEndOfStream Then plageActuelle = Trim(flux.ReadLine)
    flux.Close
End If

' Securite : Si une ligne est lue vide, on remet "0"
If etatActuel = "" Then etatActuel = "0"
If modeActuel = "" Then modeActuel = "0"
If plageActuelle = "" Then plageActuelle = "0"

statut = IIf(etatActuel = "1", "ACTIF", "INACTIF")
modeTxt = IIf(modeActuel = "0", "Faux chargement", "Blocage Strict")

' 2. Affichage du Menu personnalisé
choix = InputBox("--- PARAMETRES ---" & vbCrLf & _
                 "1. Statut: " & statut & "." & vbCrLf & _
                 "2. Mode: " & modeTxt & "." & vbCrLf & _
                 "3. Plages horraires" & vbCrLf & _
                 "4. Relancer le programme", "Parametres")

Select Case choix
    Case "1"
        ' CORRECTION : Condition stricte pour basculer le 0 en 1
        If etatActuel = "1" Then
            etatActuel = "0"
        Else
            etatActuel = "1"
        End If
        
        Sauvegarder settingsFile, etatActuel, modeActuel, plageActuelle
        MsgBox "Statut mis a jour ! (Nouveau statut : " & IIf(etatActuel = "1", "ACTIF", "INACTIF") & ")", 64, "Anti-Distractions Infinity"
        
    Case "2"
        If modeActuel = "1" Then
            modeActuel = "0"
        Else
            modeActuel = "1"
        End If
        
        Sauvegarder settingsFile, etatActuel, modeActuel, plageActuelle
        MsgBox "Mode de blocage mis a jour !", 64, "Anti-Distractions Infinity"

    Case "3"
        shell.Run "wscript " & Chr(34) & currentDir & "\Time.vbs" & Chr(34)
        
    Case "4"
        shell.Run "wscript " & Chr(34) & currentDir & "\dis.vbs" & Chr(34), 0, False
        shell.Run "wscript " & Chr(34) & currentDir & "\Time-launch.vbs" & Chr(34), 0, False
        MsgBox "Le programme a ete relance.", 64, "Anti-Distractions Infinity"

    Case Else
        WScript.Quit
End Select

Sub Sauvegarder(fichier, etat, mode, plage)
    Set flux = fso.CreateTextFile(fichier, True)
    flux.WriteLine etat
    flux.WriteLine mode
    flux.WriteLine plage
    flux.Close
End Sub

Function IIf(expr, t, f)
    If expr Then IIf = t Else IIf = f
End Function